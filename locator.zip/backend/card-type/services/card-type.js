'use strict';

/**
 * Card Type service
 */

const { createCoreService } = require("@strapi/strapi").factories;
module.exports = createCoreService("api::card-type.card-type");
