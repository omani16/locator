'use strict';

/**
 * Card Offer service
 */

const { createCoreService } = require("@strapi/strapi").factories;
module.exports = createCoreService("api::card-offer.card-offer");
