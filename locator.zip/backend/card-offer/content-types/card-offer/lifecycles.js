/** @format */
"use strict";

// Import your cache service
const cacheService = require('../../../../extensions/cache-service');

module.exports = {
  async afterCreate() {
    cacheService.clear();
    console.log("[CACHE] Cleared after page create");
  },

  async afterUpdate() {
    cacheService.clear();
    console.log("[CACHE] Cleared after page update");
  },

  async afterDelete() {
    cacheService.clear();
    console.log("[CACHE] Cleared after page delete");
  },
};