'use strict';

const { createCoreController } = require('@strapi/strapi').factories;

const today = () =>
  new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Muscat' });

module.exports = createCoreController('api::card-offer.card-offer', () => ({
  async find(ctx) {
    const date = today();
    const userFilters = ctx.query.filters || {};

    ctx.query = {
      ...ctx.query,
      filters: {
        $and: [
          userFilters,
          // active (offers created before this field existed have null, so they count as active)
          { $or: [{ isActive: { $null: true } }, { isActive: { $eq: true } }] },
          // started already, or no start date
          { $or: [{ validFrom: { $null: true } }, { validFrom: { $lte: date } }] },
          // not expired, or no end date
          { $or: [{ validTo: { $null: true } }, { validTo: { $gte: date } }] },
        ],
      },
    };

    return super.find(ctx);
  },
}));