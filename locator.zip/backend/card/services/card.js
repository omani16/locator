'use strict';

/**
 * Card service
 */

const { createCoreService } = require("@strapi/strapi").factories;
module.exports = createCoreService("api::card.card");
