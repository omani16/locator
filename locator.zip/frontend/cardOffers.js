// frontend/src/lib/cardOffers.js
import axios from "axios";
import qs from "qs";

const STRAPI_URL = process.env.NEXT_PUBLIC_STRAPI_URL || "http://localhost:1337";

const api = (path, params) =>
  axios.get(`${STRAPI_URL}/api${path}`, {
    params,
    paramsSerializer: { serialize: (p) => qs.stringify(p, { encodeValuesOnly: true }) },
  });

/**
 * Fetch card offers (expired ones are already hidden by the Strapi controller)
 * type / card = documentId of the card type / card
 */
export async function fetchCardOffers({ locale = "en", type = "", card = "", limit = 100 } = {}) {
  const filters = {};

  if (type && card) {
    filters.cards = {
      documentId: { $eq: card },
      cardType: { documentId: { $eq: type } },
    };
  } else if (card) {
    filters.cards = { documentId: { $eq: card } };
  } else if (type) {
    filters.cards = { cardType: { documentId: { $eq: type } } };
  }

  try {
    const { data } = await api("/card-offers", {
      locale,
      filters,
      populate: {
        image: true,
        cards: { populate: ["cardType"] },
      },
      sort: ["order:asc", "createdAt:desc"],
      pagination: { pageSize: limit },
    });

    const list = data?.data || [];

    // Offers with no number go last; ties keep Strapi's order (newest first)
    return [...list].sort(
      (a, b) =>
        (a.order ?? Number.MAX_SAFE_INTEGER) - (b.order ?? Number.MAX_SAFE_INTEGER)
    );
  } catch (error) {
    console.error("fetchCardOffers error:", error?.response?.data || error.message);
    return [];
  }
}

/** Fetch all card types and all cards (with their type) for the filter dropdowns */
export async function fetchCardOptions(locale = "en") {
  try {
    const [typesRes, cardsRes] = await Promise.all([
      api("/card-types", { locale, sort: ["name:asc"] }),
      api("/cards", {
        locale,
        populate: ["cardType"],
        sort: ["name:asc"],
        pagination: { pageSize: 100 },
      }),
    ]);
    return {
      cardTypes: typesRes.data?.data || [],
      cards: cardsRes.data?.data || [],
    };
  } catch (error) {
    console.error("fetchCardOptions error:", error?.response?.data || error.message);
    return { cardTypes: [], cards: [] };
  }
}

/** Build the link object passed to DynamicNewsCard as cardRedirection */
export function buildOfferLink(offer) {
  if (!offer?.link) return null;
  const external = /^https?:\/\//i.test(offer.link);
  return {
    url: offer.link,
    href: offer.link,
    text: offer.linkText,
    label: offer.linkText,
    title: offer.linkText,
    target: external ? "_blank" : "_self",
  };
}