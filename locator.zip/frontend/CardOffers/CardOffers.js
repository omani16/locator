import { useEffect, useId, useMemo, useState } from "react";
import { useRouter } from "next/router";
import DynamicNewsCard from "@/components/NewsCard/DynamicNewsCard";
import blogStyles from "@/components/section/BlogSection/BlogSection.module.scss";
import styles from "./CardOffers.module.scss";
import { useTranslation } from "next-i18next";
import { fetchCardOffers, fetchCardOptions, buildOfferLink } from "@/lib/cardOffers";

const stripHtml = (html = "") =>
  html.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();

/* ---------- inline icons (no extra dependency) ---------- */
const SearchIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2" />
    <path d="M20 20l-3.5-3.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

const FilterIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M4 7h10M18 7h2M4 17h2M10 17h10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <circle cx="16" cy="7" r="2.2" stroke="currentColor" strokeWidth="2" />
    <circle cx="8" cy="17" r="2.2" stroke="currentColor" strokeWidth="2" />
  </svg>
);

const CloseIcon = ({ size = 14 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
  </svg>
);

const ChevronIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const EmptyIcon = () => (
  <svg width="64" height="64" viewBox="0 0 64 64" fill="none" aria-hidden="true">
    <rect x="8" y="16" width="48" height="34" rx="6" stroke="currentColor" strokeWidth="2.5" />
    <path d="M8 26h48" stroke="currentColor" strokeWidth="2.5" />
    <path d="M16 40h12" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
    <circle cx="48" cy="48" r="10" fill="#f5f5f5" stroke="currentColor" strokeWidth="2.5" />
    <path d="M44.5 44.5l7 7M51.5 44.5l-7 7" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
  </svg>
);

/* ---------- Active filter chip ---------- */
const Chip = ({ label, value, onRemove, removeLabel }) => (
  <span className={styles.chip}>
    <span className={styles.chip__label}>{label}:</span>
    <span className={styles.chip__value}>{value}</span>
    <button type="button" onClick={onRemove} aria-label={`${removeLabel}: ${label} ${value}`}>
      <CloseIcon size={12} />
    </button>
  </span>
);

/**
 * Props:
 *  - sectionHead: { subtitle, title, description }
 *  - isDescriptionFullWidth: boolean
 *  - showFilters: boolean (default true) - shows search + dropdowns
 *  - defaultType / defaultCard: documentId to pre-select (optional)
 *  - limit: max offers to load (default 100)
 */
export default function CardOffers({
  sectionHead,
  isDescriptionFullWidth = false,
  showFilters = true,
  defaultType = "",
  defaultCard = "",
  limit = 100,
}) {
  const { locale = "en" } = useRouter();
  const { t } = useTranslation("common");
  const isAr = locale === "ar";   
  const uid = useId();

  const [cardTypes, setCardTypes] = useState([]);
  const [cards, setCards] = useState([]);
  const [offers, setOffers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [type, setType] = useState(defaultType);
  const [card, setCard] = useState(defaultCard);
  const [search, setSearch] = useState("");

  // Dropdown options (reload when language changes)
  useEffect(() => {
    if (!showFilters) return;
    let active = true;
    fetchCardOptions(locale).then(({ cardTypes, cards }) => {
      if (!active) return;
      setCardTypes(cardTypes);
      setCards(cards);
    });
    return () => {
      active = false;
    };
  }, [locale, showFilters]);

  // Offers (reload when language, type or card changes)
  useEffect(() => {
    let active = true;
    setLoading(true);
    fetchCardOffers({ locale, type, card, limit }).then((data) => {
      if (!active) return;
      setOffers(data);
      setLoading(false);
    });
    return () => {
      active = false;
    };
  }, [locale, type, card, limit]);

  // Card dropdown only shows cards of the selected type
  const visibleCards = useMemo(
    () => (type ? cards.filter((c) => c.cardType?.documentId === type) : cards),
    [cards, type]
  );

  // Instant client-side search on the loaded offers
  const filteredOffers = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return offers;
    return offers.filter((o) =>
      [o.title, stripHtml(o.description), o.linkText].some((v) =>
        (v || "").toLowerCase().includes(q)
      )
    );
  }, [offers, search]);

  const selectedTypeName = cardTypes.find((c) => c.documentId === type)?.name;
  const selectedCardName = cards.find((c) => c.documentId === card)?.name;
  const trimmedSearch = search.trim();
  const activeCount = [type, card, trimmedSearch].filter(Boolean).length;
  const hasActiveFilters = activeCount > 0;

  const clearAll = () => {
    setType("");
    setCard("");
    setSearch("");
  };

  return (
    <section
      className={`${blogStyles.news__and__events__block} ${styles.co}`}
      dir={isAr ? "rtl" : "ltr"}>
      <div className="container">
        {(sectionHead?.subtitle || sectionHead?.title || sectionHead?.description) && (
          <div className="row">
            <div className={"col-12 " + (isDescriptionFullWidth ? "col-xl-12" : "col-xl-7")}>
              {sectionHead?.subtitle && (
                <h6 className="secondary__subtitle fade-in-up">{sectionHead.subtitle}</h6>
              )}
              {sectionHead?.title && (
                <h2
                  className={
                    blogStyles.news__and__events__block__title + " primary__title fade-in-up"
                  }>
                  {sectionHead.title}
                </h2>
              )}
              {sectionHead?.description && (
                <p className="primary__subdescription fade-in-up">{sectionHead.description}</p>
              )}
            </div>
          </div>
        )}

        {/* ---------------- Filter panel ---------------- */}
        {showFilters && (
          <div className={styles.panel}>
            {/* Header */}
            <div className={styles.panel__header}>
              <div className={styles.panel__title}>
                <span className={styles.panel__titleIcon}>
                  <FilterIcon />
                </span>
                <span>{t.filters}</span>
                {activeCount > 0 && <span className={styles.badge}>{activeCount}</span>}
              </div>

              {hasActiveFilters && (
                <button type="button" className={styles.clear__all} onClick={clearAll}>
                  {t("cardOffersClearAll")}
                </button>
              )}
            </div>

            {/* Fields */}
            <div className={styles.panel__grid}>
              {/* Search */}
              <div className={`${styles.field} ${styles.field__search}`}>
                <label className={styles.label} htmlFor={`${uid}-search`}>
                  {t("cardOffersSearchChip")}
                </label>
                <div className={styles.control}>
                  <span className={styles.search__icon}>
                    <SearchIcon />
                  </span>
                  <input
                    id={`${uid}-search`}
                    type="text"
                    className={styles.search__input}
                    placeholder={t("cardOffersSearchPlaceholder")}
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    onKeyDown={(e) => e.key === "Escape" && setSearch("")}
                    autoComplete="off"
                  />
                  {search && (
                    <button
                      type="button"
                      className={styles.search__clear}
                      onClick={() => setSearch("")}
                      aria-label={t("cardOffersClearSearch")}>
                      <CloseIcon size={14} />
                    </button>
                  )}
                </div>
              </div>

              {/* Card type */}
              <div className={styles.field}>
                <label className={styles.label} htmlFor={`${uid}-type`}>
                  {t("cardOffersType")}
                </label>
                <div className={styles.control}>
                  <select
                    id={`${uid}-type`}
                    className={styles.select}
                    value={type}
                    onChange={(e) => {
                      setType(e.target.value);
                      setCard("");
                    }}>
                    <option value="">{t("cardOffersAllTypes")}</option>
                    {cardTypes.map((ct) => (
                      <option key={ct.documentId} value={ct.documentId}>
                        {ct.name}
                      </option>
                    ))}
                  </select>
                  <span className={styles.select__icon}>
                    <ChevronIcon />
                  </span>
                </div>
              </div>

              {/* Card name */}
              <div className={styles.field}>
                <label className={styles.label} htmlFor={`${uid}-card`}>
                  {t("cardOffersCard")}
                </label>
                <div className={styles.control}>
                  <select
                    id={`${uid}-card`}
                    className={styles.select}
                    value={card}
                    disabled={visibleCards.length === 0}
                    onChange={(e) => setCard(e.target.value)}>
                    <option value="">{t("cardOffersAllCards")}</option>
                    {visibleCards.map((c) => (
                      <option key={c.documentId} value={c.documentId}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                  <span className={styles.select__icon}>
                    <ChevronIcon />
                  </span>
                </div>
              </div>
            </div>
            {/* Result count + active chips */}
            <div className={styles.panel__footer}>
              <p className={styles.count} role="status" aria-live="polite">
                {!loading &&
                (filteredOffers.length === 1
                    ? t("cardOffersResultsOne")
                    : t("cardOffersResultsMany", {
                        count: filteredOffers.length.toLocaleString(isAr ? "ar-EG" : "en-US", {
                        useGrouping: false,
                        }),
                    }))}
              </p>
              {hasActiveFilters && (
                <div className={styles.chips}>
                  {selectedTypeName && (
                    <Chip
                      label={t("cardOffersType")}
                      value={selectedTypeName}
                      removeLabel={t.removeFilter}
                      onRemove={() => {
                        setType("");
                        setCard("");
                      }}
                    />
                  )}
                  {selectedCardName && (
                    <Chip
                      label={t("cardOffersCard")}
                      value={selectedCardName}
                      removeLabel={t.removeFilter}
                      onRemove={() => setCard("")}
                    />
                  )}
                  {trimmedSearch && (
                    <Chip
                      label={t("cardOffersSearchChip")}
                      value={trimmedSearch}
                      removeLabel={t.removeFilter}
                      onRemove={() => setSearch("")}
                    />
                  )}
                </div>
              )}
            </div>
          </div>
        )}

       {/* ---------------- Results ---------------- */}
        <div className={blogStyles.blog__section__card__wrapper}>
        {/* Empty state (outside the animated row so it is always visible) */}
        {!loading && filteredOffers.length === 0 && (
            <div className={styles.empty} role="status">
            <div className={styles.empty__icon}>
                <EmptyIcon />
            </div>
            <h3 className={styles.empty__title}>
                {hasActiveFilters ? t("cardOffersEmptyFilteredTitle") : t("cardOffersEmptyTitle")}
            </h3>
            <p className={styles.empty__text}>
                {hasActiveFilters ? t("cardOffersEmptyFilteredText") : t("cardOffersEmptyText")}
            </p>
            {hasActiveFilters && (
                <button type="button" className={styles.empty__btn} onClick={clearAll}>
                {t("cardOffersResetFilters")}
                </button>
            )}
            </div>
        )}

        {(loading || filteredOffers.length > 0) && (
            <div className="row fade-in-up">
            {loading &&
                [0, 1, 2].map((i) => (
                <div className="col-12 col-md-6 col-lg-4 mb_50" key={i}>
                    <div className={styles.skeleton}>
                    <div className={styles.skeleton__img} />
                    <div className={styles.skeleton__line} />
                    <div className={`${styles.skeleton__line} ${styles.short}`} />
                    </div>
                </div>
                ))}

            {!loading &&
                filteredOffers.map((data) => (
                <div className="col-12 col-md-6 col-lg-4 mb_50" key={data.documentId}>
                    <DynamicNewsCard
                    cardThumbnail={data?.image}
                    cardTitle={data?.title}
                    cardSubHead={stripHtml(data?.description)}
                    cardRedirection={buildOfferLink(data)}
                    addclassName="blogs__card blogs__card--content"
                    />
                </div>
                ))}
            </div>
        )}
        </div>
      </div>
    </section>
  );
}