/** @format */

import React, { useEffect, useRef } from "react";
import styles from "./MapSection.module.scss";
import mapboxgl from "mapbox-gl";
import { useTranslation } from "next-i18next";
const MapSection = () => {
  const mapContainerRef = useRef();
  const mapRef = useRef();
  const { t } = useTranslation("common");
  mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_API_KEY;

  const locations = [
    {
      name: "Al Buraimi branch",
      address: "Next to hyper market,Aremees st.,Al buraimi",
      coordinates: [56.24998, 24.25661],
      facilities: ["Disability friendly", "ATM service"],
      schedule: [
        { day: "Monday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Tuesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Wednesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Thursday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Friday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Saturday", time: "", status: "Closed" },
        { day: "Sunday", time: "", status: "Closed" },
      ],
      phone: "+968 25 666600",
    },
    {
      name: "Ibri branch",
      address: "Ruwi street",
      coordinates: [55.77249, 23.22534],
      facilities: ["Disability friendly", "ATM service"],
      schedule: [
        { day: "Monday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Tuesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Wednesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Thursday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Friday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Saturday", time: "", status: "Closed" },
        { day: "Sunday", time: "", status: "Closed" },
      ],
      phone: "+968 25 666600",
    },
    {
      name: "Barka branch",
      address: "Near Lulu Hyper Market",
      coordinates: [57.85337, 23.69529],
      facilities: ["Disability friendly", "ATM service"],
      schedule: [
        { day: "Monday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Tuesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Wednesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Thursday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Friday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Saturday", time: "", status: "Closed" },
        { day: "Sunday", time: "", status: "Closed" },
      ],
      phone: "+968 25 666600",
    },
    {
      name: "Sohar branch",
      address: "Near Lulu Hyper Market",
      coordinates: [56.70435, 24.35884],
      facilities: ["Disability friendly", "ATM service"],
      schedule: [
        { day: "Monday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Tuesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Wednesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Thursday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Friday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Saturday", time: "", status: "Closed" },
        { day: "Sunday", time: "", status: "Closed" },
      ],
      phone: "+968 25 666600",
    },
    {
      name: "Sur branch",
      address: "Near Lulu Hyper Market",
      coordinates: [59.52893, 22.57308],
      facilities: ["Disability friendly", "ATM service"],
      schedule: [
        { day: "Monday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Tuesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Wednesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Thursday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Friday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Saturday", time: "", status: "Closed" },
        { day: "Sunday", time: "", status: "Closed" },
      ],
      phone: "+968 25 666600",
    },
    {
      name: "Salalah branch",
      address: "Near Lulu Hyper Market",
      coordinates: [54.07786, 17.01946],
      facilities: ["Disability friendly", "ATM service"],
      schedule: [
        { day: "Monday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Tuesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Wednesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Thursday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Friday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Saturday", time: "", status: "Closed" },
        { day: "Sunday", time: "", status: "Closed" },
      ],
      phone: "+968 25 666600",
    },
    {
      name: "Al Amrat branch",
      address: "Near Lulu Hyper Market",
      coordinates: [58.6326, 23.5764],
      facilities: ["Disability friendly", "ATM service"],
      schedule: [
        { day: "Monday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Tuesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Wednesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Thursday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Friday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Saturday", time: "", status: "Closed" },
        { day: "Sunday", time: "", status: "Closed" },
      ],
      phone: "+968 25 666600",
    },
    {
      name: "Al Khuwayriyyah branch",
      address: "Majan industrial rd.",
      coordinates: [56.6844, 23.8398],
      facilities: ["Disability friendly"],
      schedule: [
        { day: "Monday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Tuesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Wednesday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Thursday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Friday", time: "8:00AM - 03:00 PM", status: "Open" },
        { day: "Saturday", time: "", status: "Closed" },
        { day: "Sunday", time: "", status: "Closed" },
      ],
      phone: "+968 24 730000",
    },
  ];
  useEffect(() => {
    setTheLocations();
    return () => {
      mapRef.current.remove();
    };
  }, []);

  function setTheLocations() {
    mapRef.current = new mapboxgl.Map({
      container: mapContainerRef.current, // container ref
      style: "mapbox://styles/mapbox/streets-v12", // style URL
      center: locations[0]?.coordinates, // starting position [lng, lat]
      zoom: 5, // starting zoom
    });
    // Disable the default scroll zoom behavior
    mapRef.current.scrollZoom.disable();

    // Add custom wheel event listener
    mapRef.current.on("wheel", (e) => {
      if (e.originalEvent.ctrlKey) {
        mapRef.current.scrollZoom.enable();
      } else {
        mapRef.current.scrollZoom.disable();
      }
    });
    locations.forEach((location, index) => {
      // Create a custom marker
      const el = document.createElement("div");
      el.className = "custom-marker";
      el.style.backgroundImage = "url(/assets/icons/mapicon.svg)";
      // el.style.width = "58px";
      // el.style.height = "74px";
      // el.style.backgroundSize = "100%";

      // Create a div element for the popup content
      const popupContent = document.createElement("div");
      popupContent.className = "custom_map__popup";
      popupContent.innerHTML = `
    <h3>${location.name}</h3>
    <p>${location.address}</p>
    <div className="custom__popup__selectbox">
      <input type="checkbox" name="mapboxcheckbox${index}" id="mapboxcheckbox${index}" />
      <label
        for="mapboxcheckbox${index}"
        className="custom__popup__selectbox__active">
        ${location.schedule[0].day} - ${location.schedule[0].time}
      </label>
      <ul>
        ${location.schedule
          .map((item, index) =>
            index != 0
              ? `
              <li>
                ${item.day} - ${item.time}
              </li>`
              : null
          )
          .join("")}
      </ul>
    </div>
    <p className="d-flex">
    <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M11.6116 8.12356C11.5384 8.05021 11.4514 7.99201 11.3556 7.9523C11.2599 7.9126 11.1573 7.89216 11.0536 7.89216C10.9499 7.89216 10.8473 7.9126 10.7516 7.9523C10.6558 7.99201 10.5688 8.05021 10.4956 8.12356L9.23754 9.38157C8.65428 9.20794 7.56591 8.81333 6.87611 8.12356C6.1863 7.43379 5.79168 6.34546 5.61804 5.76223L6.87611 4.50421C6.94946 4.43099 7.00766 4.34401 7.04737 4.24827C7.08708 4.15252 7.10751 4.04989 7.10751 3.94624C7.10751 3.84259 7.08708 3.73996 7.04737 3.64421C7.00766 3.54847 6.94946 3.46149 6.87611 3.38826L3.71911 0.231399C3.64588 0.158045 3.5589 0.0998497 3.46315 0.0601436C3.3674 0.0204376 3.26477 0 3.16111 0C3.05746 0 2.95482 0.0204376 2.85907 0.0601436C2.76332 0.0998497 2.67635 0.158045 2.60311 0.231399L0.462671 2.37175C0.162756 2.67166 -0.00614308 3.08363 0.000170908 3.50428C0.0183236 4.62812 0.315871 8.53158 3.39236 11.6079C6.46885 14.6843 10.3725 14.9811 11.4972 15H11.5193C11.936 15 12.3298 14.8358 12.6282 14.5375L14.7686 12.3972C14.842 12.3239 14.9001 12.237 14.9399 12.1412C14.9796 12.0455 15 11.9428 15 11.8392C15 11.7355 14.9796 11.6329 14.9399 11.5372C14.9001 11.4414 14.842 11.3544 14.7686 11.2812L11.6116 8.12356ZM11.5114 13.4208C10.5264 13.4042 7.15629 13.1398 4.50836 10.4912C1.85175 7.83471 1.59445 4.45292 1.57867 3.4877L3.16111 1.90533L5.20211 3.94624L4.18161 4.9667C4.08884 5.05939 4.02064 5.17374 3.98316 5.2994C3.94567 5.42507 3.9401 5.5581 3.96694 5.68646C3.98588 5.77722 4.44917 7.92941 5.75932 9.23951C7.06947 10.5496 9.22175 11.0129 9.31252 11.0318C9.4408 11.0594 9.57397 11.0543 9.69976 11.0169C9.82555 10.9795 9.93991 10.9111 10.0323 10.8179L11.0536 9.79749L13.0946 11.8384L11.5114 13.4208Z" fill="white"/>
</svg>

      Tel: ${location.phone}
    </p>
    <div className="d-flex custom_map__popup__footer">
      <div>
        <h6>Facilities</h6>
        <ul>
          ${location.facilities.map((facility) => `<li>${facility}</li>`).join("")}
        </ul>
      </div>
      <a href="https://www.google.com/maps/dir/?api=1&destination=${location.coordinates[1]},${location.coordinates[0]}" className="cta__btn cta__btn__primary" target="_blank" rel="noopener noreferrer"><svg width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6.2 11.475H7.85V9H10.7375V11.0625L13.625 8.175L10.7375 5.2875V7.35H7.025C6.79125 7.35 6.59531 7.42906 6.43719 7.58719C6.27906 7.74531 6.2 7.94125 6.2 8.175V11.475ZM9.5 17.25C9.29375 17.25 9.09094 17.2088 8.89156 17.1263C8.69219 17.0438 8.51 16.92 8.345 16.755L1.745 10.155C1.58 9.99 1.45625 9.80781 1.37375 9.60844C1.29125 9.40906 1.25 9.20625 1.25 9C1.25 8.79375 1.29125 8.59094 1.37375 8.39156C1.45625 8.19219 1.58 8.01 1.745 7.845L8.345 1.245C8.51 1.08 8.69219 0.95625 8.89156 0.87375C9.09094 0.79125 9.29375 0.75 9.5 0.75C9.70625 0.75 9.90906 0.79125 10.1084 0.87375C10.3078 0.95625 10.49 1.08 10.655 1.245L17.255 7.845C17.42 8.01 17.5438 8.19219 17.6263 8.39156C17.7088 8.59094 17.75 8.79375 17.75 9C17.75 9.20625 17.7088 9.40906 17.6263 9.60844C17.5438 9.80781 17.42 9.99 17.255 10.155L10.655 16.755C10.49 16.92 10.3078 17.0438 10.1084 17.1263C9.90906 17.2088 9.70625 17.25 9.5 17.25Z" fill="white"/>
</svg>        Directions
      </a>
    </div>
  `;

      // Append the popup content to the body to measure its height
      document.body.appendChild(popupContent);
      const popupHeight = popupContent.offsetHeight;
      document.body.removeChild(popupContent);

      // Create the popup with dynamic offset
      const popup = new mapboxgl.Popup({
        offset: [0, popupHeight + 35], // Offset based on the height of the popup content
        closeButton: true,
        closeOnClick: true,
        anchor: "bottom",
      }).setDOMContent(popupContent);

      // Create the marker and set the popup
      const marker = new mapboxgl.Marker(el)
        .setLngLat(location.coordinates)
        .setPopup(popup)
        .addTo(mapRef.current);

      // Add click event to center the map on the marker
      marker.getElement().addEventListener("click", () => {
        const offset = [0, popupHeight / 2];
        const centerWithOffset = mapRef.current.project(location.coordinates);
        centerWithOffset.x += offset[0];
        centerWithOffset.y += offset[1];
        const newCenter = mapRef.current.unproject(centerWithOffset);

        mapRef.current.flyTo({
          center: newCenter,
          essential: true,
        });
        // popup.trackPointer();
      });
    });
  }
  return (
    <section className={styles.map__section__section}>
      <div className="container">
        <h5 className="secondary__subtitle fade-in-up">Find</h5>
        <h2 className="primary__title fade-in-up">ATM & Branch Locator</h2>
        <div
          className={styles.map__section__section__filter + " row fade-in-up"}>
          <fieldset className="col-12 col-xl-6 d-flex">
            <input
              type="text"
              name="searchlocation"
              id="searchlocation"
              placeholder={t("searchForLocation")}
            />
            <button className="cta__btn cta__btn__primary" type="button">
              {t("searchBtn")}
            </button>
          </fieldset>
          <fieldset className="col-12 col-xl-6 ">
            <div className={styles.filter__block__wrap}>
              <p>{t("filterBy")}</p>
              <div className={styles.filter__block__wrap__row}>
                <div className={styles.location__filter__cards}>
                  <input
                    type="checkbox"
                    name="filterlocationsbyatm"
                    id="filterlocationsbyatm"
                  />
                  <label
                    htmlFor="filterlocationsbyatm"
                    className={styles.location__filter__cards__inner}>
                    <svg
                      width="16"
                      height="11"
                      viewBox="0 0 16 11"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M1 5.5L5.667 10L15 1"
                        stroke="white"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    {t("atm")}
                  </label>
                </div>
                <div className={styles.location__filter__cards}>
                  <input
                    type="checkbox"
                    name="filterlocationsbybranch"
                    id="filterlocationsbybranch"
                    defaultChecked
                  />
                  <label
                    htmlFor="filterlocationsbybranch"
                    className={styles.location__filter__cards__inner}>
                    <svg
                      width="16"
                      height="11"
                      viewBox="0 0 16 11"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M1 5.5L5.667 10L15 1"
                        stroke="white"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    {t("branches")}
                  </label>
                </div>
                {/* <div className={styles.location__filter__cards}>
                  <input
                    type="checkbox"
                    name="filterbybranchesopennow"
                    id="filterbybranchesopennow"
                    defaultChecked
                  />
                  <label
                    htmlFor="filterbybranchesopennow"
                    className={styles.location__filter__cards__inner}>
                    <svg
                      width="16"
                      height="11"
                      viewBox="0 0 16 11"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M1 5.5L5.667 10L15 1"
                        stroke="white"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    Open now
                  </label>
                </div> */}
              </div>
            </div>
          </fieldset>
        </div>
        <div
          id="map"
          ref={mapContainerRef}
          className={styles.map__container + " fade-in-up"}></div>
      </div>
    </section>
  );
};

export default MapSection;
