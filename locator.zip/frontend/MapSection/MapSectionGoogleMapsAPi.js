/** @format */
import React, { useEffect, useMemo, useRef, useState } from "react";
import styles from "./MapSection.module.scss";
import { GoogleMap, useJsApiLoader, Marker, InfoWindow } from "@react-google-maps/api";
import { useTranslation } from "next-i18next";
import axios from "axios";
import { useRouter } from "next/router";

const mapContainerStyle = { width: "100%", height: "100%" };

/* ----------------------------- Helpers ----------------------------- */
const toCoords = (loc) => {
  const lat = parseFloat((loc?.cordinates?.latitude || "").toString().trim());
  const lng = parseFloat((loc?.cordinates?.longitude || "").toString().trim());
  return isNaN(lat) || isNaN(lng) ? null : { lat, lng };
};

const getKey = (loc) => loc.documentId || loc.id;

const distanceKm = (a, b) => {
  const R = 6371;
  const rad = (d) => (d * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat);
  const dLng = rad(b.lng - a.lng);
  const x =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
};

const escapeRegExp = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const Highlight = ({ text = "", query = "" }) => {
  if (!query) return <>{text}</>;
  const parts = text.split(new RegExp(`(${escapeRegExp(query)})`, "gi"));
  return (
    <>
      {parts.map((part, i) =>
        part.toLowerCase() === query.toLowerCase() ? <mark key={i}>{part}</mark> : part
      )}
    </>
  );
};

/* ------------------------------ Icons ------------------------------ */
const Svg = ({ children, size = 16, ...p }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true" {...p}>
    {children}
  </svg>
);
const SearchIcon = (p) => (
  <Svg {...p}>
    <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="1.8" />
    <path d="M20 20l-3.5-3.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);
const CloseIcon = (p) => (
  <Svg {...p}>
    <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </Svg>
);
const PinIcon = (p) => (
  <Svg {...p}>
    <path d="M12 21s7-6.2 7-11.5A7 7 0 005 9.5C5 14.8 12 21 12 21z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" />
    <circle cx="12" cy="9.5" r="2.5" stroke="currentColor" strokeWidth="1.7" />
  </Svg>
);
const ClockIcon = (p) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="8.5" stroke="currentColor" strokeWidth="1.7" />
    <path d="M12 7.5V12l3 2" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
  </Svg>
);
const PhoneIcon = (p) => (
  <Svg {...p}>
    <path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" />
  </Svg>
);
const DirectionsIcon = (p) => (
  <Svg {...p}>
    <path d="M12 3l9 9-9 9-9-9 9-9z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" />
    <path d="M9 14v-2.5A1.5 1.5 0 0110.5 10H15m0 0l-2-2m2 2l-2 2" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const LocateIcon = (p) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="3.5" stroke="currentColor" strokeWidth="1.8" />
    <path d="M12 2v3M12 19v3M2 12h3M19 12h3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
  </Svg>
);
const ChevronIcon = (p) => (
  <Svg {...p}>
    <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const CheckIcon = (p) => (
  <Svg {...p}>
    <path d="M5 12.5l4.5 4.5L19 7.5" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const ListIcon = (p) => (
  <Svg {...p}>
    <path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </Svg>
);
const MapIcon = (p) => (
  <Svg {...p}>
    <path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2-6-2zM9 4v14M15 6v14" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" />
  </Svg>
);

/* =================================================================== */
/* --------------------------- Info window --------------------------- */
const LocationPopup = ({ location, typeText, distanceText, onClose, t }) => {
  const timings = Array.isArray(location.timings) ? location.timings : [];
  const facilities = Array.isArray(location.Facilities) ? location.Facilities : [];
  const [firstTiming, ...otherTimings] = timings;

  return (
    <div className={styles.popup}>
      <button
        type="button"
        className={styles.popup__close}
        onClick={onClose}
        aria-label={t("close", "Close")}
      >
        <CloseIcon size={14} />
      </button>

      {/* Header */}
      <div className={styles.popup__head}>
        <div className={styles.popup__tags}>
          <span
            className={`${styles.popup__tag} ${
              location.locationType === "Atm" ? styles.isAtm : styles.isBranch
            }`}
          >
            {typeText}
          </span>
          {location.governorate?.title && (
            <span className={styles.popup__gov}>{location.governorate.title}</span>
          )}
          {distanceText && <span className={styles.popup__distance}>{distanceText}</span>}
        </div>
        <h3 className={styles.popup__title}>{location.name}</h3>
      </div>

      {/* Details */}
      <div className={styles.popup__body}>
        {location.address && (
          <div className={styles.popup__row}>
            <PinIcon size={16} />
            <span>{location.address}</span>
          </div>
        )}

        {firstTiming && (
          <div className={styles.popup__row}>
            <ClockIcon size={16} />
            {otherTimings.length > 0 ? (
              <details className={styles.popup__hours}>
                <summary>
                  <span>
                    {firstTiming.day} · {firstTiming.time}
                  </span>
                  <ChevronIcon size={14} />
                </summary>
                <ul>
                  {otherTimings.map((tm, i) => (
                    <li key={i}>
                      <span>{tm.day}</span>
                      <span>{tm.time}</span>
                    </li>
                  ))}
                </ul>
              </details>
            ) : (
              <span>
                {firstTiming.day} · {firstTiming.time}
              </span>
            )}
          </div>
        )}

        {location.contactNumber && (
          <div className={styles.popup__row}>
            <PhoneIcon size={16} />
            <a href={`tel:${location.contactNumber}`} dir="ltr">
              {location.contactNumber}
            </a>
          </div>
        )}

        {facilities.length > 0 && (
          <div className={styles.popup__facilities}>
            <span className={styles.popup__label}>{t("facilities")}</span>
            <ul>
              {facilities.map((f, i) => (
                <li key={i}>{f.text || f}</li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Actions */}
      {(location.googleMapUrl || location.contactNumber) && (
        <div className={styles.popup__footer}>
          {location.contactNumber && (
            <a href={`tel:${location.contactNumber}`} className={styles.popup__btn}>
              <PhoneIcon size={15} /> {t("call", "Call")}
            </a>
          )}
          {location.googleMapUrl && (
            <a
              href={location.googleMapUrl}
              target="_blank"
              rel="noopener noreferrer"
              className={`${styles.popup__btn} ${styles.isPrimary}`}
            >
              <DirectionsIcon size={15} /> {t("directions")}
            </a>
          )}
        </div>
      )}
    </div>
  );
};
const MapSectionGoogleMaps = ({ sectionHead }) => {
  const { t } = useTranslation("common");
  const router = useRouter();
  const { locale: activeLocale } = router;
  const { isLoaded } = useJsApiLoader({
    id: "google-map-script",
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY,
  });
  const [mapCenter, setMapCenter] = useState({ lat: 23.258, lng: 58.443 });
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [fetchedLocations, setFetchedLocations] = useState([]);
  const [allGovernorates, setAllGovernorates] = useState([]);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [loading, setLoading] = useState(true);

  // Filters
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [selectedType, setSelectedType] = useState(""); // "" | "Atm" | "Branch"
  const [selectedGovs, setSelectedGovs] = useState([]); // [documentId]

  // Mobile: which pane is visible
  const [mobileView, setMobileView] = useState("map"); // "list" | "map"

  // Locate me
  const [showUserLocation, setShowUserLocation] = useState(false);
  const [userLocation, setUserLocation] = useState(null);
  const [isFetchingLocation, setIsFetchingLocation] = useState(false);

  // Governorate dropdown
  const [govOpen, setGovOpen] = useState(false);
  const govRef = useRef(null);

  const skipFitRef = useRef(false); // keep the map on the user after "Clear all"
  const autoLocateRef = useRef(false); // request location only once on load
  const mapRef = useRef(null);
  const userMarkerRef = useRef(null);
  const itemRefs = useRef({});
  const nearbyViewRef = useRef(false); // true = map is focused on the user
  const [fitTick, setFitTick] = useState(0); // bump to force the map to refit

  const iconUrl = "/assets/icons/mapicon.svg";
  // Change 28 to make the icon bigger or smaller (e.g. 24 = smaller)
  const markerIcon = useMemo(() => {
    if (!isLoaded || !window.google?.maps) return undefined;
    const size = 50;
    return {
      url: iconUrl,
      scaledSize: new window.google.maps.Size(size, size),
      anchor: new window.google.maps.Point(size / 2, size),
    };
  }, [isLoaded]);
  /* ------------------------------ Data ------------------------------ */

  useEffect(() => {
    fetchLocations();
    fetchGovernorates();
    setSelectedGovs([]); // ids differ per locale
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeLocale]);

  const fetchGovernorates = async () => {
    try {
      const res = await axios.get("/api/governorates", {
        params: { locale: activeLocale, "pagination[pageSize]": 100, sort: "title:asc" },
      });
      setAllGovernorates(res?.data?.data || []);
    } catch (e) {
      console.error("Governorates fetch failed:", e?.response?.status, e?.message);
      setAllGovernorates([]);
    }
  };

  const fetchLocations = async () => {
    setLoading(true);
    try {
      const qs = [
        `locale=${activeLocale}`,
        `pagination[pageSize]=200`,
        `populate[governorate][fields][0]=title`,
        `populate[cordinates]=true`,
        `populate[timings]=true`,
        `populate[Facilities]=true`,
      ].join("&");

      const response = await axios.get(`/api/locations?${qs}`);
      const locations = response?.data?.data || [];
      setFetchedLocations(locations);

      const first = locations.map(toCoords).find(Boolean);
      if (first) setMapCenter(first);
    } catch (error) {
      console.error("Failed to fetch locations:", error);
      setFetchedLocations([]);
    } finally {
      setLoading(false);
    }
  };

  /* --------------------------- Derived data -------------------------- */

  const governorateOptions = useMemo(() => {
    const source = allGovernorates.length
      ? allGovernorates
      : fetchedLocations.map((l) => l.governorate).filter(Boolean);
    const seen = new Set();
    return source
      .filter((g) => g?.documentId && g?.title && !seen.has(g.documentId) && seen.add(g.documentId))
      .map((g) => ({ id: g.documentId, title: g.title }))
      .sort((a, b) => a.title.localeCompare(b.title, activeLocale));
  }, [allGovernorates, fetchedLocations, activeLocale]);

  // label = plural (filter tabs), tagLabel = singular (tag on list cards)
  const typeOptions = [
    { value: "Branch", label: t("branches"), tagLabel: t("branch") },
    { value: "Atm", label: t("atms"), tagLabel: t("atm") },
  ];
  const typeLabel = (v) => typeOptions.find((o) => o.value === v)?.tagLabel || v;

  // `skip` builds faceted counts (e.g. governorate counts ignore the governorate filter)
  const matches = (loc, skip) => {
    const q = query.toLowerCase().trim();
    if (q) {
      const hit =
        (loc.name || "").toLowerCase().includes(q) ||
        (loc.address || "").toLowerCase().includes(q) ||
        (loc.governorate?.title || "").toLowerCase().includes(q);
      if (!hit) return false;
    }
    if (skip !== "gov" && selectedGovs.length && !selectedGovs.includes(loc.governorate?.documentId))
      return false;
    if (skip !== "type" && selectedType && loc.locationType !== selectedType) return false;
    return true;
  };

  const filteredLocations = useMemo(
    () => fetchedLocations.filter((loc) => matches(loc)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [fetchedLocations, query, selectedGovs, selectedType]
  );

  // Cards: add distance (when location is known) and sort nearest first
  const cards = useMemo(() => {
    const list = filteredLocations.map((loc) => {
      const coords = toCoords(loc);
      return {
        loc,
        coords,
        distance: userLocation && coords ? distanceKm(userLocation, coords) : null,
      };
    });
    if (userLocation) {
      list.sort((a, b) => (a.distance ?? Infinity) - (b.distance ?? Infinity));
    }
    return list;
  }, [filteredLocations, userLocation]);

  const govCounts = useMemo(() => {
    const out = {};
    fetchedLocations.filter((l) => matches(l, "gov")).forEach((l) => {
      const id = l.governorate?.documentId;
      if (id) out[id] = (out[id] || 0) + 1;
    });
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchedLocations, query, selectedType]);

  const typeCounts = useMemo(() => {
    const out = { all: 0, Atm: 0, Branch: 0 };
    fetchedLocations.filter((l) => matches(l, "type")).forEach((l) => {
      out.all += 1;
      if (out[l.locationType] !== undefined) out[l.locationType] += 1;
    });
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchedLocations, query, selectedGovs]);

  const hasFilters = !!(query.trim() || selectedType || selectedGovs.length);

  /* ----------------------------- Effects ----------------------------- */

  // On first load, sort by the nearest branches (silent if denied)
  useEffect(() => {
    if (autoLocateRef.current) return;
    autoLocateRef.current = true;
    setShowUserLocation(true);
    getUserLocation(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Debounce the search text before re-fitting the map
  useEffect(() => {
    const id = setTimeout(() => setDebouncedQuery(query), 350);
    return () => clearTimeout(id);
  }, [query]);

  const fitToResults = () => {
    if (!mapRef.current || !window.google?.maps) return;

    // Stay on the user only while the nearby view is active
    if (nearbyViewRef.current && userLocation && !hasFilters) {
      mapRef.current.panTo(userLocation);
      mapRef.current.setZoom(14);
      return;
    }

    const points = filteredLocations.map(toCoords).filter(Boolean);
    if (points.length === 0) return;
    if (points.length === 1) {
      mapRef.current.panTo(points[0]);
      mapRef.current.setZoom(15);
      return;
    }
    const bounds = new window.google.maps.LatLngBounds();
    points.forEach((p) => bounds.extend(p));
    mapRef.current.fitBounds(bounds, 60);
  };

  // Zoom the map to the results when filters change
  useEffect(() => {
    if (fitTick.current) {
      fitTick.current = false;
      return;
    }
    fitToResults();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedGovs, selectedType, debouncedQuery, mapLoaded, fetchedLocations, fitTick]);

  // Google Maps needs a resize nudge after being un-hidden on mobile
  useEffect(() => {
    if (mobileView !== "map" || !mapRef.current || !window.google?.maps) return;
    const id = setTimeout(() => {
      window.google.maps.event.trigger(mapRef.current, "resize");
      const coords = selectedLocation && toCoords(selectedLocation);
      if (coords) mapRef.current.panTo(coords);
      else fitToResults();
    }, 60);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mobileView]);

  // Drop the popup if its location got filtered out
  useEffect(() => {
    if (selectedLocation && !filteredLocations.some((l) => getKey(l) === getKey(selectedLocation))) {
      setSelectedLocation(null);
    }
  }, [filteredLocations, selectedLocation]);

  // Keep the active card visible in the list
  useEffect(() => {
    if (!selectedLocation) return;
    itemRefs.current[getKey(selectedLocation)]?.scrollIntoView({
      block: "nearest",
      behavior: "smooth",
    });
  }, [selectedLocation]);

  // User location marker
  useEffect(() => {
    if (!window.google?.maps || !userLocation || !mapRef.current) return;
    if (userMarkerRef.current) userMarkerRef.current.setMap(null);

    userMarkerRef.current = new window.google.maps.Marker({
      position: userLocation,
      map: mapRef.current,
      title: t("youAreHere"),
      icon: {
        url: "https://maps.google.com/mapfiles/ms/micons/blue-dot.png",
        scaledSize: new window.google.maps.Size(40, 40),
      },
    });

    return () => {
      if (userMarkerRef.current) userMarkerRef.current.setMap(null);
    };
  }, [userLocation, mapLoaded, t]);

  // Close the governorate dropdown on outside click / Escape
  useEffect(() => {
    if (!govOpen) return;
    const onDown = (e) => {
      if (govRef.current && !govRef.current.contains(e.target)) setGovOpen(false);
    };
    const onKey = (e) => e.key === "Escape" && setGovOpen(false);
    document.addEventListener("mousedown", onDown);
    document.addEventListener("touchstart", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("touchstart", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [govOpen]);

  /* ----------------------------- Handlers ---------------------------- */

  const toggleGov = (id) =>
    setSelectedGovs((prev) => (prev.includes(id) ? prev.filter((v) => v !== id) : [...prev, id]));

  // silent = true: no alerts (used for the automatic request on page load)
  const getUserLocation = (silent = false) => {
    if (!navigator.geolocation) {
      if (!silent) alert(t("geolocationNotSupported"));
      setShowUserLocation(false);
      return;
    }
    setIsFetchingLocation(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const newLocation = { lat: position.coords.latitude, lng: position.coords.longitude };
        nearbyViewRef.current = true;
        setUserLocation(newLocation);
        if (mapRef.current) {
          mapRef.current.panTo(newLocation);
          mapRef.current.setZoom(14);
        }
        setIsFetchingLocation(false);
      },
      (error) => {
        console.error("Geolocation error:", error);
        if (!silent) alert(t("locationAccessDenied"));
        setShowUserLocation(false);
        setIsFetchingLocation(false);
      },
      { timeout: 10000, maximumAge: 60000 }
    );
  };

  // Reset all filters and jump to the user's location (nearest first)
  // const clearAll = () => {
  //   nearbyViewRef.current = false;
  //   setQuery("");
  //   setDebouncedQuery("");
  //   setSelectedType("");
  //   setSelectedGovs([]);
  //   setGovOpen(false);
  //   setFitTick((n) => n + 1);
  // };
  // Reset all filters and go back to the initial view: nearby locations
const clearAll = () => {
  setQuery("");
  setDebouncedQuery("");
  setSelectedType("");
  setSelectedGovs([]);
  setGovOpen(false);
  setSelectedLocation(null);

  if (userLocation) {
    // Location already known: back to the nearby view
    nearbyViewRef.current = true;
    setShowUserLocation(true);
    if (mapRef.current) {
      mapRef.current.panTo(userLocation);
      mapRef.current.setZoom(14);
    }
  } else {
    // Location not known yet (denied, or turned off): ask again quietly,
    // and show all locations in the meantime
    nearbyViewRef.current = false;
    setShowUserLocation(true);
    if (!isFetchingLocation) getUserLocation(true);
  }

  setFitTick((n) => n + 1);
};

  const toggleLocateMe = () => {
    const next = !showUserLocation;
    setShowUserLocation(next);
    if (next) {
      getUserLocation();
    } else {
      nearbyViewRef.current = false;
      setUserLocation(null);
      if (userMarkerRef.current) {
        userMarkerRef.current.setMap(null);
        userMarkerRef.current = null;
      }
    }
  };

  const focusLocation = (location) => {
    setSelectedLocation(location);
    const coords = toCoords(location);
    if (mapRef.current && coords) {
      mapRef.current.panTo(coords);
      mapRef.current.setZoom(15);
    }
  };

  const handleCardClick = (location) => {
    focusLocation(location);
    if (typeof window !== "undefined" && window.matchMedia("(max-width: 900px)").matches) {
      setMobileView("map");
    }
  };
  const nf = (n) =>
    Number(n).toLocaleString(activeLocale === "ar" ? "ar-EG" : "en-US", { useGrouping: false });
  const formatDistance = (km) =>
    km < 1
      ? `${nf(Math.round(km * 1000))} ${t("unitM", "m")}`
      : `${nf(km.toFixed(1))} ${t("unitKm", "km")}`;
  /* ------------------------------ Render ----------------------------- */

  const resultLabel = `${filteredLocations.length} ${t("locationsFound", "locations")}`;

  const govLabel =
    selectedGovs.length === 0
      ? t("allGovernorates", "All governorates")
      : selectedGovs.length === 1
      ? governorateOptions.find((g) => g.id === selectedGovs[0])?.title || t("governorate", "Governorate")
      : `${t("governorate", "Governorate")} (${selectedGovs.length})`;

  const typeTabs = [
    { value: "", label: t("all", "All"), count: typeCounts.all },
    ...typeOptions.map((o) => ({ ...o, count: typeCounts[o.value] || 0 })),
  ];

  return (
    <section className={styles.map__section__section}>
      <div className="container">
        {sectionHead?.subtitle && (
          <h5 className="secondary__subtitle fade-in-up">{sectionHead.subtitle}</h5>
        )}
        {sectionHead?.title && <h2 className="primary__title fade-in-up">{sectionHead.title}</h2>}
        {sectionHead?.description && (
          <p className="primary__subdescription fade-in-up">{sectionHead.description}</p>
        )}

        <div className={`${styles.locator} fade-in-up`} data-view={mobileView}>
          {/* ========================== Toolbar ========================== */}
          <div className={styles.toolbar}>
            <div className={styles.toolbar__row}>
              {/* Search */}
              <div className={styles.search}>
                <SearchIcon size={18} className={styles.search__icon} />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder={t("searchForLocations")}
                  aria-label={t("searchForLocations")}
                  autoComplete="off"
                />
                {query && (
                  <button
                    type="button"
                    className={styles.search__clear}
                    onClick={() => setQuery("")}
                    aria-label={t("clear", "Clear")}
                  >
                    <CloseIcon size={14} />
                  </button>
                )}
              </div>

              {/* Type: segmented control */}
              <div className={styles.tabs} role="tablist" aria-label={t("type", "Type")}>
                {typeTabs.map((tab) => (
                  <button
                    key={tab.value || "all"}
                    type="button"
                    role="tab"
                    aria-selected={selectedType === tab.value}
                    className={`${styles.tab} ${selectedType === tab.value ? styles.isActive : ""}`}
                    onClick={() => {
                      nearbyViewRef.current = false;
                      setSelectedType(tab.value);
                      setFitTick((n) => n + 1);
                    }}
                  >
                    {tab.label}
                    <span>{tab.count}</span>
                  </button>
                ))}
              </div>

              {/* Governorate: multi-select dropdown */}
              {governorateOptions.length > 0 && (
                <div className={styles.dropdown} ref={govRef}>
                  <button
                    type="button"
                    className={`${styles.dropdown__trigger} ${selectedGovs.length ? styles.isActive : ""}`}
                    onClick={() => setGovOpen((o) => !o)}
                    aria-haspopup="listbox"
                    aria-expanded={govOpen}
                  >
                    <PinIcon size={16} />
                    <span className={styles.dropdown__label}>{govLabel}</span>
                    <ChevronIcon size={16} className={govOpen ? styles.isOpen : ""} />
                  </button>

                  {govOpen && (
                    <div className={styles.dropdown__menu}>
                      <div className={styles.dropdown__head}>
                        <span>{t("governorate", "Governorate")}</span>
                        {selectedGovs.length > 0 && (
                          <button type="button" className={styles.linkBtn} onClick={() => setSelectedGovs([])}>
                            {t("clear", "Clear")}
                          </button>
                        )}
                      </div>
                      <ul className={styles.dropdown__list} role="listbox" aria-multiselectable="true">
                        {governorateOptions.map((g) => {
                          const active = selectedGovs.includes(g.id);
                          const count = govCounts[g.id] || 0;
                          const disabled = count === 0 && !active;
                          return (
                            <li key={g.id} role="option" aria-selected={active}>
                              <button
                                type="button"
                                className={`${styles.option} ${active ? styles.isActive : ""}`}
                                onClick={() => toggleGov(g.id)}
                                disabled={disabled}
                              >
                                <span className={styles.option__box}>{active && <CheckIcon size={12} />}</span>
                                <span className={styles.option__title}>{g.title}</span>
                                <span className={styles.option__count}>{count}</span>
                              </button>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Meta row */}
            <div className={styles.meta}>
              <span className={styles.meta__count} aria-live="polite">
                {resultLabel}
              </span>
              <div className={styles.meta__actions}>
                {hasFilters && (
                  <button type="button" className={styles.linkBtn} onClick={clearAll}>
                    {t("clearAll", "Clear all")}
                  </button>
                )}
                <button
                  type="button"
                  className={`${styles.nearBtn} ${showUserLocation ? styles.isActive : ""}`}
                  onClick={toggleLocateMe}
                  aria-pressed={showUserLocation}
                  disabled={isFetchingLocation}
                >
                  <LocateIcon />
                  {isFetchingLocation ? t("locating", "Locating...") : t("locateMe")}
                </button>
              </div>
            </div>
          </div>

          {/* ============================ Body ============================ */}
          <div className={styles.body}>
            {/* ============================= Map ============================= */}
            <div className={`${styles.mapWrap} ${isFetchingLocation ? styles.isBusy : ""}`}>
                {isLoaded ? (
                  <GoogleMap
                    mapContainerStyle={mapContainerStyle}
                    center={mapCenter}
                    zoom={7}
                    onLoad={(map) => {
                      mapRef.current = map;
                      setMapLoaded(true);
                    }}
                    options={{ disableDefaultUI: false, zoomControl: true, streetViewControl: false, mapTypeControl: false }}
                  >
                    {filteredLocations.map((loc) => {
                      const coords = toCoords(loc);
                      if (!coords) return null;
                      const isActive = selectedLocation && getKey(selectedLocation) === getKey(loc);
                      return (
                        <Marker
                          key={getKey(loc)}
                          position={coords}
                          icon={markerIcon}
                          zIndex={isActive ? 999 : undefined}
                          onClick={() => focusLocation(loc)}
                        />
                      );
                    })}

                  {selectedLocation &&
  (() => {
    const coords = toCoords(selectedLocation);
    if (!coords) return null;

    const timings = Array.isArray(selectedLocation.timings) ? selectedLocation.timings : [];
    const facilities = Array.isArray(selectedLocation.Facilities) ? selectedLocation.Facilities : [];
    const key = getKey(selectedLocation);

    return (
      <InfoWindow
        position={coords}
        onCloseClick={() => setSelectedLocation(null)}
        options={{
          pixelOffset: new window.google.maps.Size(0, -40),
          maxWidth: 380,
        }}
      >
        <div className={styles.iw}>
          {/* Header */}
          <div className={styles.iw__header}>
            <div className={styles.iw__badges}>
              <span className={styles.iw__tag}>{typeLabel(selectedLocation.locationType)}</span>
              {selectedLocation.governorate?.title && (
                <span className={styles.iw__gov}>{selectedLocation.governorate.title}</span>
              )}
            </div>
            <h3 className={styles.iw__title}>{selectedLocation.name}</h3>
          </div>

          {/* Body */}
          <div className={styles.iw__body}>
            {selectedLocation.address && (
              <div className={styles.iw__row}>
                <PinIcon size={16} />
                <span>{selectedLocation.address}</span>
              </div>
            )}

            {timings.length > 0 &&
              (timings.length > 1 ? (
                <details className={styles.iw__hours} key={`t-${key}`}>
                  <summary className={styles.iw__row}>
                    <ClockIcon size={16} />
                    <span>
                      {timings[0].day} · {timings[0].time}
                    </span>
                    <ChevronIcon size={16} className={styles.iw__chev} />
                  </summary>
                  <ul className={styles.iw__hoursList}>
                    {timings.slice(1).map((timing, i) => (
                      <li key={i}>
                        <span>{timing.day}</span>
                        <span>{timing.time}</span>
                      </li>
                    ))}
                  </ul>
                </details>
              ) : (
                <div className={styles.iw__row}>
                  <ClockIcon size={16} />
                  <span>
                    {timings[0].day} · {timings[0].time}
                  </span>
                </div>
              ))}

            {selectedLocation.contactNumber && (
              <div className={styles.iw__row}>
                <PhoneIcon size={16} />
                <a href={`tel:${selectedLocation.contactNumber}`} dir="ltr">
                  {selectedLocation.contactNumber}
                </a>
              </div>
            )}

            {facilities.length > 0 && (
              <div className={styles.iw__facilities}>
                <span className={styles.iw__label}>{t("facilities")}</span>
                <ul>
                  {facilities.map((f, i) => (
                    <li key={i}>{f.text || f}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Footer */}
          {(selectedLocation.googleMapUrl || selectedLocation.contactNumber) && (
            <div className={styles.iw__footer}>
              {selectedLocation.contactNumber && (
                <a href={`tel:${selectedLocation.contactNumber}`} className={styles.iw__btnGhost}>
                  <PhoneIcon size={15} /> {t("call", "Call")}
                </a>
              )}
              {selectedLocation.googleMapUrl && (
                <a
                  href={selectedLocation.googleMapUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={styles.iw__btnPrimary}
                >
                  <DirectionsIcon size={15} /> {t("directions")}
                </a>
              )}
            </div>
          )}
        </div>
      </InfoWindow>
    );
  })()}
                </GoogleMap>
                ) : (
                  <div style={{ width: "100%", height: "100%", background: "#eee" }} />
                )}
            </div>

            {/* ============================ List ============================= */}
            <aside className={styles.panel}>
              <ul className={styles.panel__list}>
                {loading &&
                  Array.from({ length: 5 }).map((_, i) => (
                    <li key={i} className={styles.skeleton} aria-hidden="true" />
                  ))}

                {!loading && cards.length === 0 && (
                  <li className={styles.emptyState}>
                    <PinIcon size={32} />
                    <strong>{t("noLocationsFound", "No locations found")}</strong>
                    <p>{t("tryDifferentFilters", "Try a different search or remove some filters.")}</p>
                    {hasFilters && (
                      <button type="button" onClick={clearAll}>
                        {t("clearAll", "Clear all")}
                      </button>
                    )}
                  </li>
                )}

                {!loading &&
                  cards.map(({ loc, distance }) => {
                    const key = getKey(loc);
                    const isActive = selectedLocation && getKey(selectedLocation) === key;
                    const timing = Array.isArray(loc.timings) ? loc.timings[0] : null;
                    const q = query.trim();
                    return (
                      <li
                        key={key}
                        ref={(el) => (itemRefs.current[key] = el)}
                        className={`${styles.card} ${isActive ? styles.isActive : ""}`}
                        onClick={() => handleCardClick(loc)}
                      >
                        <div className={styles.card__head}>
                          <span
                            className={`${styles.tag} ${
                              loc.locationType === "Atm" ? styles.tagAtm : styles.tagBranch
                            }`}
                          >
                            {typeLabel(loc.locationType)}
                          </span>
                          {loc.governorate?.title && (
                            <span className={styles.card__gov}>{loc.governorate.title}</span>
                          )}
                          {distance !== null && (
                            <span className={styles.card__distance}>
                              {formatDistance(distance)}
                            </span>
                          )}
                        </div>

                        <h3 className={styles.card__name}>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleCardClick(loc);
                            }}
                          >
                            <Highlight text={loc.name} query={q} />
                          </button>
                        </h3>

                        {loc.address && (
                          <p className={styles.card__row}>
                            <PinIcon />
                            <span>
                              <Highlight text={loc.address} query={q} />
                            </span>
                          </p>
                        )}
                        {timing && (
                          <p className={styles.card__row}>
                            <ClockIcon />
                            <span>
                              {timing.day} · {timing.time}
                            </span>
                          </p>
                        )}

                        {(loc.contactNumber || loc.googleMapUrl) && (
                          <div className={styles.card__actions}>
                            {loc.contactNumber && (
                              <a href={`tel:${loc.contactNumber}`} onClick={(e) => e.stopPropagation()}>
                                <PhoneIcon /> {t("call", "Call")}
                              </a>
                            )}
                            {loc.googleMapUrl && (
                              <a
                                href={loc.googleMapUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={(e) => e.stopPropagation()}
                              >
                                <DirectionsIcon /> {t("directions")}
                              </a>
                            )}
                          </div>
                        )}
                      </li>
                    );
                  })}
              </ul>
            </aside>

            {/* Mobile List / Map toggle */}
            <div className={styles.viewToggle}>
              <button
                type="button"
                className={mobileView === "list" ? styles.isActive : ""}
                onClick={() => setMobileView("list")}
              >
                <ListIcon /> {t("list", "List")}
              </button>
              <button
                type="button"
                className={mobileView === "map" ? styles.isActive : ""}
                onClick={() => setMobileView("map")}
              >
                <MapIcon /> {t("map", "Map")}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MapSectionGoogleMaps;